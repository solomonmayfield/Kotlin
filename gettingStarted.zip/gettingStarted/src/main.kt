/**
 * #2 Kotlin Hello World: Write your first code in Kotlin and Run it in INTELLIJ IDEA
 * https://www.youtube.com/watch?v=G6oVG5XetnE
 *Kotlin Android Beginner Tutorial: How to write
 * code in Kotlin and run it in Intellij IDEA.
 * Kotlin is now official Android Language as
 * declared in Google I/O. Say bye bye to Java and say Hello World in Kotlin.
 */


fun main(args: Array<String>) {
    println("Hello World")

}